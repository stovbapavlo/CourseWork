﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lab3
{
    class HashTable
    {
        private int size;
        private LinkedList<Node>[] buckets;

        public HashTable(int capacity)
        {
            size = 0;
            buckets = new LinkedList<Node>[capacity];
            for (int i = 0; i < capacity; i++)
            {
                buckets[i] = new LinkedList<Node>();
            }
        }

        public void Put(Key key, double value)
        {
            int index = GetIndex(key);
            LinkedList<Node> bucket = buckets[index];

            foreach (Node node in bucket)
            {
                if (node.Key.Equals(key))
                {
                    node.Value = value;
                    return;
                }
            }

            bucket.AddLast(new Node(key, value));
            size++;

            if ((double)size / buckets.Length > 0.75)
            {
                Resize();
            }
        }

        public double Get(Key key)
        {
            int index = GetIndex(key);
            LinkedList<Node> bucket = buckets[index];

            foreach (Node node in bucket)
            {
                if (node.Key.Equals(key))
                {
                    return node.Value;
                }
            }

            return 0; // or throw an exception indicating key not found
        }

        public bool ContainsKey(Key key)
        {
            int index = GetIndex(key);
            LinkedList<Node> bucket = buckets[index];

            foreach (Node node in bucket)
            {
                if (node.Key.Equals(key))
                {
                    return true;
                }
            }

            return false;
        }

        public double Remove(Key key)
        {
            int index = GetIndex(key);
            LinkedList<Node> bucket = buckets[index];

            foreach (Node node in bucket)
            {
                if (node.Key.Equals(key))
                {
                    bucket.Remove(node);
                    size--;
                    return node.Value;
                }
            }

            return 0; // or throw an exception indicating key not found
        }

        public int Size()
        {
            return size;
        }

        private int GetIndex(Key key)
        {
            return Math.Abs(key.GetHashCode() % buckets.Length);
        }

        private void Resize()
        {
            int newCapacity = buckets.Length * 2;
            LinkedList<Node>[] newBuckets = new LinkedList<Node>[newCapacity];

            for (int i = 0; i < newCapacity; i++)
            {
                newBuckets[i] = new LinkedList<Node>();
            }

            foreach (LinkedList<Node> bucket in buckets)
            {
                foreach (Node node in bucket)
                {
                    int newIndex = Math.Abs(node.Key.GetHashCode() % newCapacity);
                    newBuckets[newIndex].AddLast(node);
                }
            }

            buckets = newBuckets;
        }
    }
}
