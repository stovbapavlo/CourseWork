﻿using System;

namespace lab3
{
    class Program
    {
        static void Main(string[] args)
        {
            HashTable ht = new HashTable(1024);
            ht.Put(new Key("APPL", 223), 180.0);
            ht.Put(new Key("META", 300), 160.34);

            double metaPrice = ht.Get(new Key("META", 300));
            Console.WriteLine($"META price: {metaPrice}"); // Виведе "META price: 160.34"
        }
    }
}
