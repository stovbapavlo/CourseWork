﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lab3
{
    class Key
    {
        public string Stock { get; set; }
        public int DayOfYear { get; set; }

        public Key(string stock, int dayOfYear)
        {
            Stock = stock;
            DayOfYear = dayOfYear;
        }

        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }

            Key other = (Key)obj;
            return DayOfYear == other.DayOfYear && Stock.Equals(other.Stock);
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Stock, DayOfYear);
        }
    }
}
