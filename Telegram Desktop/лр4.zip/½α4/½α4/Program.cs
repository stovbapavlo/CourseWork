﻿using System;
using System.Diagnostics;
using System.Text;

namespace лр4_вар4
{
    class Program
    {
        static void Block_1_1()
        {
            Console.Write("Введіть одне натуральне (ціле строго додатне) число n: ");
            int n = int.Parse(Console.ReadLine());

            var sw = new Stopwatch();
            sw.Start();

            string str = "";
            for(int i = 1; i <= n; i++)
            {
                str += i.ToString() + " ";
            }
            Console.WriteLine(str);

            sw.Stop();
            //Console.WriteLine($"Затрачений час: {sw.ElapsedMilliseconds} млс");
        }

        static void Block_1_2()
        {
            Console.Write("Введіть одне натуральне (ціле строго додатне) число n: ");
            int n = int.Parse(Console.ReadLine());

            var sw = new Stopwatch();
            sw.Start();

            string str = "";
            for (int i = n; i >= 1; i--)
            {
                str = i.ToString() + " " + str;
            }
            Console.WriteLine(str);

            sw.Stop();
            //Console.WriteLine($"Затрачений час: {sw.ElapsedMilliseconds} млс");
        }

        static void Block_1_3()
        {
            Console.Write("Введіть одне натуральне (ціле строго додатне) число n: ");
            int n = int.Parse(Console.ReadLine());

            var sw = new Stopwatch();
            sw.Start();

            StringBuilder sb = new StringBuilder();
            for (int i = 1; i <= n; i++)
            {
                sb.Append(i + " "); 
            }
            Console.WriteLine(sb.ToString());

            sw.Stop();
            //Console.WriteLine($"Затрачений час: {sw.ElapsedMilliseconds} млс");
        }

        static void Block_1_4()
        {
            Console.Write("Введіть одне натуральне (ціле строго додатне) число n: ");
            int n = int.Parse(Console.ReadLine());

            var sw = new Stopwatch();
            sw.Start();

            StringBuilder sb = new StringBuilder();
            for (int i = n; i >= 1; i--)
            {
                sb.Insert(0, " ");
                sb.Insert(0, i);
            }
            Console.WriteLine(sb.ToString());

            sw.Stop();
            //Console.WriteLine($"Затрачений час: {sw.ElapsedMilliseconds}  млс");
        }

        static void Block_2()
        {
            Console.Write("Введіть перший рядок: ");
            string str1 = Console.ReadLine();
            Console.Write("Введіть другий рядок: ");
            string str2 = Console.ReadLine();
            int amount = 0;
            
            if(str1.Length == str2.Length)
            {
                for (int i = 0; i < str1.Length; i++)
                {
                    if ((str1[i] == 'A' && str2[i] == 'А') || (str1[i] == 'a' && str2[i] == 'а') || (str1[i] == 'B' && str2[i] == 'В') || 
                        (str1[i] == 'C' && str2[i] == 'С') || (str1[i] == 'c' && str2[i] == 'с') || (str1[i] == 'E' && str2[i] == 'Е') || 
                        (str1[i] == 'e' && str2[i] == 'е') || (str1[i] == 'H' && str2[i] == 'Н') || (str1[i] == 'I' && str2[i] == 'І') || 
                        (str1[i] == 'K' && str2[i] == 'К') || (str1[i] == 'M' && str2[i] == 'М') || (str1[i] == 'O' && str2[i] == 'О') || 
                        (str1[i] == 'o' && str2[i] == 'о') || (str1[i] == 'P' && str2[i] == 'Р') || (str1[i] == 'p' && str2[i] == 'р') || 
                        (str1[i] == 'T' && str2[i] == 'Т') || (str1[i] == 'X' && str2[i] == 'Х') || (str1[i] == 'x' && str2[i] == 'х') || 
                        (str1[i] == 'y' && str2[i] == 'у') ||

                        (str2[i] == 'A' && str1[i] == 'А') || (str2[i] == 'a' && str1[i] == 'а') || (str2[i] == 'B' && str1[i] == 'В') ||
                        (str2[i] == 'C' && str1[i] == 'С') || (str2[i] == 'c' && str1[i] == 'с') || (str2[i] == 'E' && str1[i] == 'Е') ||
                        (str2[i] == 'e' && str1[i] == 'е') || (str2[i] == 'H' && str1[i] == 'Н') || (str2[i] == 'I' && str1[i] == 'І') ||
                        (str2[i] == 'K' && str1[i] == 'К') || (str2[i] == 'M' && str1[i] == 'М') || (str2[i] == 'O' && str1[i] == 'О') ||
                        (str2[i] == 'o' && str1[i] == 'о') || (str2[i] == 'P' && str1[i] == 'Р') || (str2[i] == 'p' && str1[i] == 'р') ||
                        (str2[i] == 'T' && str1[i] == 'Т') || (str2[i] == 'X' && str1[i] == 'Х') || (str2[i] == 'x' && str1[i] == 'х') ||
                        (str2[i] == 'y' && str1[i] == 'у'))//перша літера латинска, друга - кирилична
                    {
                        amount++;
                    }
                    else
                    {
                        if ((str1[i] != str2[i]))
                        {
                            amount = 0;
                            break;
                        }
                    }
                }
            }

            if(amount > 0)
            {
                Console.WriteLine("Візуально однакові");
            }
            else
            {
                if (str1 != str2)
                {
                    Console.WriteLine("Різні");
                }
                else
                {
                    Console.WriteLine("Однакові");
                }
            }
        }

        static void Main(string[] args)
        {
            string choice;
            do
            {
                Console.WriteLine("Для виконання блоку 1 версії 1 введіть 1.1");
                Console.WriteLine("Для виконання блоку 1 версії 2 введіть 1.2");
                Console.WriteLine("Для виконання блоку 1 версії 3 введіть 1.3");
                Console.WriteLine("Для виконання блоку 1 версії 4 введіть 1.4");
                Console.WriteLine("Для виконання блоку 2 (варіант 4) введіть 2");
                Console.WriteLine("Для виходу з програми введіть 0");
                choice = Console.ReadLine();
                switch (choice)
                {
                    case "1.1":
                        Console.WriteLine("Виконую блок 1 версію 1");
                        Block_1_1();
                        break;
                    case "1.2":
                        Console.WriteLine("Виконую блок 1 версію 2");
                        Block_1_2();
                        break;
                    case "1.3":
                        Console.WriteLine("Виконую блок 1 версію 3");
                        Block_1_3();
                        break;
                    case "1.4":
                        Console.WriteLine("Виконую блок 1 версію 4");
                        Block_1_4();
                        break;
                    case "2":
                        Console.WriteLine("Виконую блок 2");
                        Block_2();
                        break;
                    case "0":
                        Console.WriteLine("Зараз завершимо, тільки натисніть будь ласка ще раз Enter");
                        Console.ReadLine();
                        break;
                    default:
                        Console.WriteLine("Команда ''{0}'' не розпізнана. Зробіть, будь ласка, вибір із 1, 1.2, 1.3, 1.4, 2, 0.", choice);
                        break;
                }
            } while (choice != "0");
        }
    }
}
