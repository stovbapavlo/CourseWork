﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lab2
{
    class TuringMachine
    {
        private Dictionary<string, Dictionary<char, Transition>> transitions;
        List<char> alphabet;
        private string currentState;
        private int headPosition;
        private string tape;

        public TuringMachine(Dictionary<string, Dictionary<char, Transition>> transitions, List<char> alphabet, string initialState, int initialHeadPosition, string initialTape)
        {
            this.transitions = transitions;
            this.alphabet = alphabet;
            currentState = initialState;
            headPosition = initialHeadPosition;
            tape = initialTape;
        }

        public void Run()
        {
            while (currentState != "#")
            {
                if (!alphabet.Contains(tape[headPosition]))
                {
                    Console.WriteLine("Invalid symbol on the tape: " + tape[headPosition]);
                    break;
                }

                if (!transitions.ContainsKey(currentState))
                {
                    Console.WriteLine("Invalid state: " + currentState);
                    break;
                }

                if (headPosition < 0 || headPosition >= tape.Length)
                {
                    Console.WriteLine("Head position is outside the bounds of the tape.");
                    break;
                }

                if (!transitions[currentState].ContainsKey(tape[headPosition]))
                {
                    Console.WriteLine("Invalid transition for state " + currentState + " and symbol " + tape[headPosition]);
                    break;
                }

                Transition transition = transitions[currentState][tape[headPosition]];
                tape = tape.Substring(0, headPosition) + transition.WriteSymbol + tape.Substring(headPosition + 1);

                if (transition.MoveDirection == 'R')
                {
                    headPosition++;
                }
                else if (transition.MoveDirection == 'L')
                {
                    headPosition--;
                }

                currentState = transition.NextState;

                Console.WriteLine("Current State: " + currentState);
                Console.WriteLine("Tape: " + tape);
                Console.WriteLine("Tape Head Position: " + headPosition);
                Console.WriteLine();
            }
        }
    }
}
