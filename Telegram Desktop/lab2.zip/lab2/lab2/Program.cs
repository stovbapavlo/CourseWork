﻿using System;
using System.Collections.Generic;

namespace lab2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<char> alphabet = new List<char> { '0', '1', 'e', 'o', '_' };

            Dictionary<string, Dictionary<char, Transition>> transitions = new Dictionary<string, Dictionary<char, Transition>>();

            transitions["s0"] = new Dictionary<char, Transition>
            {
                { '0', new Transition { WriteSymbol = '0', MoveDirection = 'R', NextState = "s1" } },
                { '1', new Transition { WriteSymbol = '1', MoveDirection = 'R', NextState = "s1" } },
                { 'e', new Transition { WriteSymbol = 'e', MoveDirection = 'R', NextState = "#" } },
                { 'o', new Transition { WriteSymbol = 'o', MoveDirection = 'R', NextState = "#" } },
                { '_', new Transition { WriteSymbol = 'e', MoveDirection = 'R', NextState = "#" } }
            };

            transitions["s1"] = new Dictionary<char, Transition>
            {
                { '0', new Transition { WriteSymbol = '0', MoveDirection = 'R', NextState = "s0" } },
                { '1', new Transition { WriteSymbol = '1', MoveDirection = 'R', NextState = "s0" } },
                { 'e', new Transition { WriteSymbol = 'e', MoveDirection = 'R', NextState = "#" } },
                { 'o', new Transition { WriteSymbol = 'o', MoveDirection = 'R', NextState = "#" } },
                { '_', new Transition { WriteSymbol = 'o', MoveDirection = 'R', NextState = "#" } }
            };

            TuringMachine tm = new TuringMachine(transitions, alphabet, "s0", 0, "011_");
            tm.Run();
        }
    }
}
