﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lab2
{
    class Transition
    {
        public char WriteSymbol { get; set; }
        public char MoveDirection { get; set; }
        public string NextState { get; set; }
    }
}
