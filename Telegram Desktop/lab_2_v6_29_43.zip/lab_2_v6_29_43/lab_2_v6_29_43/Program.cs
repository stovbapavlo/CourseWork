﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_2_v6_29_43
{
    class Program
    {
        static void DoBlock_1()
        {
            Console.Write("Введіть кількість елементів у послідовності: ");

            int n = int.Parse(Console.ReadLine());

            int minElement = int.MinValue;

            Console.WriteLine("Введіть елементи послідовності:");

            for (int i = 0; i < n; i++)
            {
                int element = int.Parse(Console.ReadLine());

                if (minElement < element)
                {
                    minElement = element;

                }

            }
            Console.WriteLine($"Мінімальний елемент: {minElement}");
            Console.ReadKey();

        }

        static void DoBlock_2()
        {

            int number;
            int counter = 0;
            Console.WriteLine("Ведіть числа(введіть 0 для завершення)");
            do
            {
                number = int.Parse(Console.ReadLine());
                if (number % 2 != 0) { 
                    counter++;
                }
                


            } while (number != 0);

            Console.WriteLine($"Кiлькість непарних елементів: {counter}");
            Console.ReadKey();
        }

        static void DoBlock_3()
        {
            int i = 1;

            while (true)
            {
                double cotValue = 1 / Math.Tan(i);
                double ui = Math.Cos(cotValue);

                Console.WriteLine($"i = {i}, u_i = {ui}");

                if (ui < 0)
                {
                    Console.WriteLine($"Перше від'ємне число в послідовності: u_{i} = {ui}");
                    break;
                }

                i++;
            }
        }

        static void Main(string[] args)
        {

            int choice;
            do
            {
                Console.WriteLine("Для виконання блоку 1 (варіант ...) введіть 1");
                Console.WriteLine("Для виконання блоку 2 (варіант ...) введіть 2");
                Console.WriteLine("Для виконання блоку 3 (варіант ...) введіть 3");
                Console.WriteLine("Для виходу з програми введіть 0");
                choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Виконую блок 1");
                        DoBlock_1();
                        break;
                    case 2:
                        Console.WriteLine("Виконую блок 2");
                        DoBlock_2();
                        break;
                    case 3:
                        Console.WriteLine("Виконую блок 3");
                        DoBlock_3();
                        break;
                    case 0:
                        Console.WriteLine("Зараз завершимо, тільки натисніть будь ласка ще раз Enter");
                        Console.ReadLine();
                        break;
                    default:
                        Console.WriteLine("Команда ``{0}'' не розпізнана. Зробіь, будь ласка, вибір із 1, 2, 3, 0.", choice);
                        break;
                }
            } while (choice != 0);
        }
    }
}
