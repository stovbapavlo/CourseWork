﻿using System;
using System.Text.RegularExpressions;

namespace F6
{
    class Program
    {
        static string searchPatt = @"\\texttt\{([A-Za-z0-9]+)\}";
        static string replacePatt = @"\begin{ttfamily}$1\end{ttfamily}";

        static void Main(string[] args)
        {
            String str = Console.ReadLine();
            while (str != null)
            {
                String newStr = Regex.Replace(str, searchPatt, match =>
                {
                    string value = match.Groups[0].Value;
                    if (value.Contains(@"\texttt{Rr0}"))
                    {
                        return value;
                    }
                    else if (value.Contains(@"\texttt{rR0}"))
                    {
                        return value;
                    }else if (value.Contains(@"\texttt{R0}"))
                    {
                        return value;
                    }
                    else if (value.Contains(@"\texttt{R0after}"))
                    {
                        return value;
                    }
                    else if (value.Contains(@"\texttt{a007}"))
                    {
                        return value;
                    }
                    else if (value.Contains(@"\texttt{R0r}"))
                    {
                        return value;
                    }
                    else if (value.Contains(@"\texttt{r0R}"))
                    {
                        return value;
                    }
                    else if (value.Contains(@"\texttt{0Rr}"))
                    {
                        return value;
                    }
                    else if (value.Contains(@"\texttt{0rR}"))
                    {
                        return value;
                    }
                    else if (value.Contains(@"\texttt{a4paper}"))
                    {
                        return value;
                    }
                    else
                    {
                        return Regex.Replace(value, searchPatt, replacePatt);
                    }
                });
                Console.WriteLine(newStr);
                str = Console.ReadLine();
            }
        }
    }
}