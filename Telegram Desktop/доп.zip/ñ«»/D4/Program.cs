﻿using System;
using System.IO;
using System.Text.RegularExpressions;

namespace D4
{
    class Program
    {
        static String searchPatt = @"\$v_{([^}]*)}\$";
        static String replacePatt = "v[$1]";

        static void Main(string[] args)
        {
            String str = Console.ReadLine();
            while (str != null)
            {

                if (str.Contains("$v_{,}$"))
                {
                    Console.WriteLine("$v_{,}$" + str.Substring("$v_{,}$".Length));
                }
                else if (str.Contains("$v_{*}$"))
                {
                    Console.WriteLine("$v_{*}$" + str.Substring("$v_{*}$".Length));
                }
                else if (str.Contains("$v_{q|1}$"))
                {
                    Console.WriteLine("$v_{q|1}$" + str.Substring("$v_{q|1}$".Length));
                }
                else if (str.Contains("$v_{+}$"))
                {
                    Console.WriteLine("$v_{+}$" + str.Substring("$v_{+}$".Length));
                }
                else if (str.Contains("$v_{-}$"))
                {
                    Console.WriteLine("$v_{-}$" + str.Substring("$v_{-}$".Length));
                }
                else if (str.Contains("$v_{[]}$"))
                {
                    Console.WriteLine("$v_{[]}$" + str.Substring("$v_{[]}$".Length));
                }
                else
                {
                    String newStr = Regex.Replace(str, searchPatt, replacePatt);
                    Console.WriteLine(newStr);
                }

                str = Console.ReadLine();
            }
        }
    }
}