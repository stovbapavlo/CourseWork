﻿using System;
using System.Text.RegularExpressions;

namespace RegExLab_A
{
    class Program
    {
        static string searchPattern = @"\\circle\{(\((\d+),(\d+)\))(,(\d+))?\}";
        static string replacePattern = @"\circle{($3,$2)$4}";


        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            while (input != null)
            {
                string replacedText = Regex.Replace(input, searchPattern, replacePattern);
                Console.WriteLine(replacedText);
                input = Console.ReadLine();
            }
        }
    }
}
