﻿using System;
using System.IO;

namespace C3
{
    class Program
    {
        static string searchPatt = @"\$v_(\w)\$"; 
        static string replacePatt = "v[$1]";
        static void Main(string[] args)
        {
            String str = Console.ReadLine();
            while (str != null)
            {
                String newStr = System.Text.RegularExpressions.Regex.Replace(str, searchPatt, replacePatt);
                Console.WriteLine(newStr);
                str = Console.ReadLine();
            }
        }
    }
}
