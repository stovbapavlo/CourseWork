﻿using System;
using System.Text.RegularExpressions;

namespace E5
{
    class Program
    {
        static String searchPatt = @"\$(v_(\w)|v_{([^}]+)}|v_{})\$";
        static String replacePatt = "v[$2$3]";

        static void Main(string[] args)
        {
            string str = Console.ReadLine();
            while (str != null)
            {
                String newStr = Regex.Replace(str, searchPatt, match =>
                {
                    string value = match.Groups[0].Value;
                    if (value.Contains("$v_{,}$"))
                    {
                        return value;
                    }
                    else if (value.Contains("$v_{*}$"))
                    {
                        return value;
                    }
                    else if (value.Contains("$v_{i_1}$"))
                    {
                        return value;
                    }
                    else if (value.Contains("$v_{q|1}$"))
                    {
                        return value;
                    }
                    else if (value.Contains("$v_{i^2}$"))
                    {
                        return value;
                    }
                    else if (value.Contains("$v_{+}$"))
                    {
                        return value;
                    }
                    else if (value.Contains("$v_{-}$"))
                    {
                        return value;
                    }
                    else if (value.Contains("$v_{}$"))
                    {
                        return "v[]";
                    }
                    else
                    {
                        return Regex.Replace(value, searchPatt, replacePatt);
                    }
                });
                Console.WriteLine(newStr);
                str = Console.ReadLine();
            }
        }
    }
}
