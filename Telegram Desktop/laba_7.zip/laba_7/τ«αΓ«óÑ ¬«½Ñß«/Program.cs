﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace чортове_колесо
{
    internal static class Program
    {

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
        public partial class Form1 : Form
        {
            public Form1()
            {
                InitializeComponent();
            }

            private void InitializeComponent()
            {
                this.SuspendLayout();
                // Додайте налаштування форми тут
                this.ResumeLayout(false);
            }

            protected override void OnPaint(PaintEventArgs e)
            {

                int circleRadius = 100;
                int circleX = (this.ClientSize.Width - circleRadius * 2) / 2;
                int circleY = (this.ClientSize.Height - circleRadius * 2) / 2;


                e.Graphics.DrawEllipse(Pens.Black, circleX, circleY, circleRadius * 2, circleRadius * 2);

                int squareSize = circleRadius / 6; // Розмір квадратів 

                for (int angle = 0; angle < 360; angle += 30)
                {

                    int squareCenterX = circleX + circleRadius + (int)(circleRadius * Math.Cos(angle * Math.PI / 180));
                    int squareCenterY = circleY + circleRadius + (int)(circleRadius * Math.Sin(angle * Math.PI / 180));


                    int squareX = squareCenterX - squareSize / 2;
                    int squareY = squareCenterY - squareSize / 2;


                    e.Graphics.DrawRectangle(Pens.Black, squareX, squareY, squareSize, squareSize);

                }
                // Обчислення координат початку та кінця ліній
                int lineStartX = circleX + circleRadius;
                int lineStartY = circleY + circleRadius;
                int lineEndX = lineStartX + (int)(2 * circleRadius * Math.Cos(45 * Math.PI / 180));
                int lineEndY = lineStartY + (int)(2 * circleRadius * Math.Sin(45 * Math.PI / 180));

                // Малювання першої лінії
                e.Graphics.DrawLine(Pens.Black, lineStartX, lineStartY, lineEndX, lineEndY);

                // Обчислення координат кінця другої лінії
                lineEndX = lineStartX - (int)(2 * circleRadius * Math.Cos(45 * Math.PI / 180));
                lineEndY = lineStartY + (int)(2 * circleRadius * Math.Sin(45 * Math.PI / 180));

                // Малювання другої лінії
                e.Graphics.DrawLine(Pens.Black, lineStartX, lineStartY, lineEndX, lineEndY);
            }
        }
    }
}
