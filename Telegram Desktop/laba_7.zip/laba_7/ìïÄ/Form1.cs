﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace НЛО
{
    public partial class Form1 : Form
    {
        private int spaceshipWidth = 200; // початкова ширина корабля
        private int spaceshipHeight = 150; // початкова висота корабля
        private int chassisX;
        private int chassisY;
        private int centerX = 500;
        private int centerY = 600;
        private int chassisWidth;
        private int chassisHeight;
        private Timer timer;
        private int spaceshipX;
        private int spaceshipY;
        private bool isLanding;
        private bool isChassisDeployed;
        private int chassisDeploySpeed = 5;

        public Form1()
        {
            this.DoubleBuffered = true;
            InitializeComponent();
            InitializeAnimation();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            StartAnimation();
        }

        private void StartAnimation()
        {
            timer = new Timer();
            timer.Interval = 10;
            timer.Tick += Timer_Tick;
            timer.Start(); // Початок таймера
        }

        private void InitializeAnimation()
        {
            chassisX = 100; // начальная координата X верхнего левого угла шасси
            chassisY = 100; // начальная координата Y верхнего левого угла шасси
            chassisWidth = 200; // начальная ширина шасси
            chassisHeight = 150; // начальная высота шасси
            spaceshipX = this.ClientSize.Width / 2;
            spaceshipY = 0;
            isLanding = false;
            isChassisDeployed = false;

            // Ініціалізація таймера для оновлення анімації
            timer = new Timer();
            timer.Interval = 10; // Інтервал оновлення
            timer.Tick += Timer_Tick;
        }

        private bool isChassisTouchingSurface = false; // Додайте змінну для відстеження дотику шасі до поверхні
        private int spaceshipSpeed = 2; // Швидкість руху НЛО
        private int planetSurfaceY = 400;

        private void Timer_Tick(object sender, EventArgs e)
        {
            spaceshipY += spaceshipSpeed; // Рух НЛО вниз

            if (spaceshipY + spaceshipHeight >= centerY - chassisHeight - chassisDeploySpeed)
            {
                spaceshipY = centerY - chassisHeight - spaceshipHeight - chassisDeploySpeed; // Зупиняємо НЛО на відстані, яка передує шасі
                isLanding = true; // Встановлюємо прапорець посадки
            }

            if (isLanding && !isChassisDeployed)
            {
                if (chassisY >= spaceshipY + spaceshipHeight)
                {
                    chassisY -= chassisDeploySpeed; // Рух шасі вгору (випуск шасі)
                }
                else
                {
                    isChassisDeployed = true; // Випущено шасі
                    spaceshipSpeed = 0; // Зупинити рух НЛО
                }
            }

            Refresh(); // Оновлюємо вікно для перефарбування
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            DrawSpaceship(e.Graphics);

            if (isChassisDeployed && isLanding)
            {
                DrawChassis(e.Graphics); // Малювати шасі, якщо воно випущене і відбувається посадка
            }

            DrawPlanetSurface(e.Graphics);
        }

        private void DrawSpaceship(Graphics g)
        {
            Pen outlinePen = new Pen(Color.White, 2);
            Brush bodyBrush = new SolidBrush(Color.Gray);
            Brush halfCircleBrush = new SolidBrush(Color.Gray);

            float x = spaceshipX; // координата X верхнього лівого кута корабля
            float y = spaceshipY; // координата Y верхнього лівого кута корабля
            int width = 200; // ширина корабля
            int height = 50; // висота корабля

            // Малюємо нижню частину дискообразного об'єкта
            g.DrawEllipse(outlinePen, x, y, width, height);
            g.FillEllipse(bodyBrush, x, y, width, height);

            // Малюємо верхню частину дискообразного об'єкта - перевернуте півколо
            int halfCircleWidth = width / 2; // ширина півкола (в два рази менше за ширину корабля)
            int halfCircleHeight = 2 * height; // висота півкола
            float halfCircleX = x + width / 4; // координата X верхнього лівого кута півкола
            float halfCircleY = y - halfCircleHeight / 3; // координата Y верхнього лівого кута півкола

            g.FillPie(halfCircleBrush, halfCircleX, halfCircleY, halfCircleWidth, halfCircleHeight, 0, -180); // Малюємо перевернуте півколо

            outlinePen.Dispose();
            bodyBrush.Dispose();
            halfCircleBrush.Dispose();
        }

        private void DrawChassis(Graphics g)
        {
            Pen outlinePen = new Pen(Color.Black, 2);

            int x1 = spaceshipX + spaceshipWidth / 3; // координата X лівої точки шасі
            int y1 = chassisY + 300; // збільшити значення y1 для зсуву шасі нижче
            int x2 = spaceshipX + 2 * spaceshipWidth / 3; // координата X правої точки шасі
            int y2 = chassisY + 300; // збільшити значення y2 для зсуву шасі нижче
            int y3Chassis = 340; // координата Y нижньої точки шасі

            int chassisHeightHalf = chassisHeight / 2; // висота шасі поділена на 2

            g.DrawLine(outlinePen, x1, y1, x1, y3Chassis); // Ліва лінія шасі
            g.DrawLine(outlinePen, x2, y2, x2, y3Chassis); // Права лінія шасі

            outlinePen.Dispose();
        }


        private void DrawPlanetSurface(Graphics g)
        {

            Brush surfaceBrush = new SolidBrush(Color.Green);

            int centerX = 500; // координата X центру поверхні
            int centerY = 600; // координата Y центру поверхні
            int radius = 75 * 3; // новий радіус поверхні (втричі більший)

            // Малюємо коло
            int x = centerX - radius;
            int y = centerY - radius;
            int width = 2 * radius;
            int height = 2 * radius;

            g.FillEllipse(surfaceBrush, x, y, width, height);

            surfaceBrush.Dispose();
        }
    }
}