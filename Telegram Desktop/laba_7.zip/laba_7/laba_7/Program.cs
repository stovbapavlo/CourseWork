﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace laba_7
{
    static class Program
    {
        /// <summary>
        /// Головна точка входу для програми.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
    /*public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // Додайте налаштування форми тут
            this.ResumeLayout(false);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            // Намалювати сегмент кола
            int segmentRadius = 100;
            int segmentStartAngle = 45;
            int segmentSweepAngle = 90;
            int segmentX = 100;
            int segmentY = 100;

            e.Graphics.DrawArc(Pens.Black, segmentX, segmentY, segmentRadius * 2, segmentRadius * 2, segmentStartAngle, segmentSweepAngle);

            // Намалювати ромб
            Point[] diamondPoints = new Point[]
            {
             new Point(300, 100),
             new Point(400, 200),
             new Point(300, 300),
             new Point(200, 200)
            };

            e.Graphics.DrawPolygon(Pens.Black, diamondPoints);

            // Намалювати зафарбований паралелограм
            Point[] parallelogramPoints = new Point[]
            {
             new Point(500, 100),
             new Point(600, 100),
             new Point(700, 300),
             new Point(600, 300)
            };

            e.Graphics.FillPolygon(Brushes.Black, parallelogramPoints);

            // Намалювати восьмикутник
            Point[] octagonPoints = new Point[]
            {
             new Point(100, 400),
             new Point(150, 400),
             new Point(200, 450),
             new Point(200, 500),
             new Point(150, 550),
             new Point(100, 550),
             new Point(50, 500),
             new Point(50, 450)
            };

            e.Graphics.DrawPolygon(Pens.Black, octagonPoints);
        }
    }*/








    /*public partial class Form1 : Form
    {
        private Timer timer;
        private int spaceshipX;
        private int spaceshipY;
        private bool isLanding;
        private bool isChassisDeployed;

        public Form1()
        {
            InitializeComponent();
            InitializeAnimation();
        }

        private void InitializeAnimation()
        {
            spaceshipX = this.ClientSize.Width / 2;
            spaceshipY = 0;
            isLanding = false;
            isChassisDeployed = false;

            // Ініціалізація таймера для оновлення анімації
            timer = new Timer();
            timer.Interval = 10; // Інтервал оновлення
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            // Оновлення позиції НЛО
            if (!isLanding)
            {
                spaceshipY += 2; // Швидкість спуску НЛО
            }
            else if (!isChassisDeployed)
            {
                // Код для випуску шасі
             
                isChassisDeployed = true;
            }
            else
            {
                // Код для приземлення на поверхню планети
               
                timer.Stop();
            }

            
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            
            DrawSpaceship(e.Graphics);

            // Малювання інших елементів анімації (шасі, поверхня планети і т.д.)
            // ...
        }

        private void DrawSpaceship(Graphics g)
        {
            // Код для малювання НЛО
            // ...
        }
    }*/
    //круг

    /*public partial class Form1 : Form
    {
        private Timer timer;
        private int centerX;
        private int centerY;
        private int radius;
        private double angle;
        private double angularSpeed;

        public Form1()
        {
            InitializeComponent();
            InitializeAnimation();
        }

        private void InitializeAnimation()
        {

            radius = 100;
            centerX = this.ClientSize.Width / 2;
            centerY = this.ClientSize.Height / 2;
            angularSpeed = 0.02;


            timer = new Timer();
            timer.Interval = 10; 
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {

            angle += angularSpeed;


            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);


            int rotatedCenterX = centerX + (int)(radius * Math.Cos(angle));
            int rotatedCenterY = centerY + (int)(radius * Math.Sin(angle));

            e.Graphics.DrawEllipse(Pens.Black, rotatedCenterX - radius, rotatedCenterY - radius, radius * 2, radius * 2);
        }
    }
*/


    //чортове колесо
    /*public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // Додайте налаштування форми тут
            this.ResumeLayout(false);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
           
            int circleRadius = 100;
            int circleX = (this.ClientSize.Width - circleRadius * 2) / 2;
            int circleY = (this.ClientSize.Height - circleRadius * 2) / 2;

            
            e.Graphics.DrawEllipse(Pens.Black, circleX, circleY, circleRadius * 2, circleRadius * 2);

            int squareSize = circleRadius / 6; // Розмір квадратів 

            for (int angle = 0; angle < 360; angle += 30)
            {
               
                int squareCenterX = circleX + circleRadius + (int)(circleRadius * Math.Cos(angle * Math.PI / 180));
                int squareCenterY = circleY + circleRadius + (int)(circleRadius * Math.Sin(angle * Math.PI / 180));

                
                int squareX = squareCenterX - squareSize / 2;
                int squareY = squareCenterY - squareSize / 2;

                
                e.Graphics.DrawRectangle(Pens.Black, squareX, squareY, squareSize, squareSize);

            }
            // Обчислення координат початку та кінця ліній
            int lineStartX = circleX + circleRadius;
            int lineStartY = circleY + circleRadius;
            int lineEndX = lineStartX + (int)(2 * circleRadius * Math.Cos(45 * Math.PI / 180));
            int lineEndY = lineStartY + (int)(2 * circleRadius * Math.Sin(45 * Math.PI / 180));

            // Малювання першої лінії
            e.Graphics.DrawLine(Pens.Black, lineStartX, lineStartY, lineEndX, lineEndY);

            // Обчислення координат кінця другої лінії
            lineEndX = lineStartX - (int)(2 * circleRadius * Math.Cos(45 * Math.PI / 180));
            lineEndY = lineStartY + (int)(2 * circleRadius * Math.Sin(45 * Math.PI / 180));

            // Малювання другої лінії
            e.Graphics.DrawLine(Pens.Black, lineStartX, lineStartY, lineEndX, lineEndY);
        }
    }
*/




}
