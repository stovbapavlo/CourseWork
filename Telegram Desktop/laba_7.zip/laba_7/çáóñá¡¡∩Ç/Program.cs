﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ЗавданняА
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
        public partial class Form1 : Form
        {
            public Form1()
            {
                InitializeComponent();
            }

            private void InitializeComponent()
            {
                this.SuspendLayout();
                // Додайте налаштування форми тут
                this.ResumeLayout(false);
            }

            protected override void OnPaint(PaintEventArgs e)
            {
                base.OnPaint(e);

                // Намалювати сегмент кола
                int segmentRadius = 100;
                int segmentStartAngle = 45;
                int segmentSweepAngle = 90;
                int segmentX = 100;
                int segmentY = 100;

                e.Graphics.DrawArc(Pens.Black, segmentX, segmentY, segmentRadius * 2, segmentRadius * 2, segmentStartAngle, segmentSweepAngle);

                // Намалювати ромб
                Point[] diamondPoints = new Point[]
                {
             new Point(300, 100),
             new Point(400, 200),
             new Point(300, 300),
             new Point(200, 200)
                };

                e.Graphics.DrawPolygon(Pens.Black, diamondPoints);

                // Намалювати зафарбований паралелограм
                Point[] parallelogramPoints = new Point[]
                {
             new Point(500, 100),
             new Point(600, 100),
             new Point(700, 300),
             new Point(600, 300)
                };

                e.Graphics.FillPolygon(Brushes.Black, parallelogramPoints);

                // Намалювати восьмикутник
                Point[] octagonPoints = new Point[]
                {
             new Point(100, 400),
             new Point(150, 400),
             new Point(200, 450),
             new Point(200, 500),
             new Point(150, 550),
             new Point(100, 550),
             new Point(50, 500),
             new Point(50, 450)
                };

                e.Graphics.DrawPolygon(Pens.Black, octagonPoints);
            }
        }
    }
}
