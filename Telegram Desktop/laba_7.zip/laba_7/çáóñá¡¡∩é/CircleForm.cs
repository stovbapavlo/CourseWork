﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ЗавданняВ
{
    partial class CircleForm : Form
    {
        private Timer timer;
        private float angle;
        private const int radius = 100;
        private const int distanceFromCenter = 150;
        private bool isCircleInFront;

        public CircleForm()
        {
            // Налаштування форми
            this.Text = "Намальоване коло";
            this.Size = new Size(800, 600);

            // Ініціалізація таймера
            timer = new Timer();
            timer.Interval = 50; // Інтервал в мілісекундах
            timer.Tick += Timer_Tick;

            // Запуск таймера
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            // Інкремент кута (в радіанах)
            angle += 0.01f;

            // Оновлення форми
            this.Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            // Отримання контексту малювання
            Graphics g = e.Graphics;

            // Налаштування графічного контексту для згладжування країв
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Отримання координат центра екрана
            int centerX = this.ClientSize.Width / 2;
            int centerY = this.ClientSize.Height / 2;

            // Малювання горизонтальної прямої
            Pen pen = new Pen(Color.Black);
            g.DrawLine(pen, 0, centerY, this.ClientSize.Width, centerY);

            // Обчислення координат кола
            int x = centerX;
            int y = (int)(centerY + distanceFromCenter * Math.Cos(angle)); // Змінено координату y

            // Обчислення координат кола у 3D вимірі
            int z = (int)(distanceFromCenter * Math.Sin(angle));

            // Малювання кола
            Pen circlePen = new Pen(Color.Red);
            circlePen.Width = 5;
            g.DrawEllipse(circlePen, x - radius, y - z - radius, radius * 2, radius * 2);
        }



        private void CircleForm_Load(object sender, EventArgs e)
        {
            // Тут ви можете розмістити початкові налаштування форми або інші дії, які потрібно виконати при завантаженні форми.
        }
    }
}
